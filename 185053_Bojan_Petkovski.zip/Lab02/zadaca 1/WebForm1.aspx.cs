﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ValidacijaKontroli2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                ddlOd.Items.Add("Berlin");
                ddlOd.Items.Add("Moscow");
                ddlOd.Items.Add("Oslo");
                ddlOd.Items.Add("Helsinki");
                ddlOd.Items.Add("Marseille");
                ddlOd.Items.Add("Lisbon");
                ddlOd.Items.Add("Stockholm");

                ddlDo.Items.Add("Bogota");
                ddlDo.Items.Add("Tokyo");
                ddlDo.Items.Add("Denver");
                ddlDo.Items.Add("Nairobi");
                ddlDo.Items.Add("Rio de Janeiro");
                ddlDo.Items.Add("Palermo");
                ddlDo.Items.Add("Skopje");

                for (int i = 1; i < 32; i++)
                {
                    ddlDen.Items.Add(i.ToString());
                }

                string[] Months = new string[12];
                Months[0] = "Jan";
                Months[1] = "Feb";
                Months[2] = "Mar";
                Months[3] = "Apr";
                Months[4] = "May";
                Months[5] = "Jun";
                Months[6] = "Jul";
                Months[7] = "Aug";
                Months[8] = "Sep";
                Months[9] = "Okt";
                Months[10] = "Nov";
                Months[11] = "Dec";

                for (int i = 0; i < 12; i++)
                {
                    ddlMesec.Items.Add(Months[i]);
                }


                int j = 2020;
                while (j > 2015)
                {
                    ddlGodina.Items.Add(j.ToString());
                    --j;
                }

                for (int i = 0; i < 24; i++)
                {
                    if (i < 10)
                    {
                        ddlVreme.Items.Add("0" + i.ToString() + ":00");

                    } else
                    {
                        ddlVreme.Items.Add(i.ToString() + ":00");
                    }
                }
            }
        }

        protected void btnPodnesi_Click(object sender, EventArgs e)
        {
            lblPatnik.Text = txtIme.Text + " " + txtPrezime.Text;
            lblSredstvo.Text = lstSredstvo.SelectedItem.ToString();
            lblOd.Text = ddlOd.SelectedItem.Text;
            lblDo.Text = ddlDo.SelectedItem.Text;
            lblVreme.Text = ddlDen.SelectedItem.Text + "." 
                          + ddlMesec.SelectedItem.Text + "." 
                          + ddlGodina.SelectedItem.Text + " at "
                          + ddlVreme.SelectedItem.Text;
            lblZona.Text = rblZona.SelectedItem.Text;
            lblKlasa.Text = rblKlasa.SelectedItem.Text;

            lblPosluga.Text = "";
            foreach (ListItem li in cblPosluga.Items)
            {
                if (li.Selected == true)
                {
                    lblPosluga.Text += li.Text + " "; 
                }
            }

            string value = lstSredstvo.SelectedItem.ToString();
            if (value == "Train")
            {
                imgSlika.ImageUrl = "https://i.kym-cdn.com/photos/images/original/001/566/301/bb8.png";

            } else
            {
                imgSlika.ImageUrl = "https://sayingimages.com/wp-content/uploads/the-laughing-airplane-meme.jpg";
            }
        }
    }
}
